// Name: Hao Gai
// SID:  606362 (GPP-E Program)
// Date: Apr. 19th, 2015

#include <iostream>
#include <forward_list>
#include <cmath>
#include "lab2.h"

using namespace std;

bool isPrime(int i) {
    if (i <= 1) {return false;}
    else if (i <= 3) {return true;}
    else if (i % 2 == 0) {return false;}
    else {
        for (int a = 3; a < (sqrt(i) + 1); a = a + 2) {
            if (! isPrime(a)) {
                continue;
            }
            else {
                if ((i % a) == 0) {return false;}
            }
        }
    }
    return true;
}

int primeCount( forward_list<int> lst ) {
    if (lst.empty()) return 0;
    int primeNum = 0;
    int temp = lst.front();
    lst.pop_front();
    if (isPrime(temp)) {
        primeNum = 1 + primeCount(lst);
    }
    else {
        primeNum = primeCount(lst);
    }
    return primeNum;
}

int main() {
    forward_list<int> first;
    first.assign({2, 3, 6, 12, 90, 113});
    cout << "List \"first\" : ";
    for (int& x: first) cout << x << " ";
    cout << endl << "There are " << primeCount(first) << " primes in list \"first\"." << endl;
    forward_list<int> second;
    second.assign({0, 2, 3});
    listCopy(first, second);
    cout << "Listcopy of list \"first\" : "; 
    for (int& x: second) cout << x << " ";
    cout << endl;
    second.assign({0, 2, 3});
    cout << "PrintLots at position 0, 2, 3: "; 
    printLots(first, second);
    List<int> third;
    third.push_back(1);
    third.push_back(2);
    third.push_back(3);
    third.push_back(4);
    third.push_back(5);
    third.push_back(6);
    cout << "My singly linked list \"third\": ";
    third.print();
    third.pop_back();
    cout << "Pop_back:";
    third.print();
    third.elementSwap(2);
    cout << "elementSwap(2): ";
    third.print();
    third.~List();
    cout << "Destructor: ";
    third.print();
}