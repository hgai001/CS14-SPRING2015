#ifndef lab2_h
#define lab2_h
#include <iostream>

using namespace std;

template <typename T>
struct Node {
    int value;
    Node *next;
};

template <typename T>
class List {
    private:
    int length;
    Node<T> *head;
    
    public:
    
    List() {
        head = 0;
        length = 0;
    }
    
    List(const List& str) {
        if (str.length == 0) {
            head = 0;
            length = 0;
            return;
        }
        head = new Node<T>;
        head->value = str.head->value;
        length = 1;
        Node<T> *current = str.head;
        for (int i = 1; i < str.length; ++i) {
            current = current->next;
            push_back(current->value);
        }
    }
    
    ~List() {
        while (length != 0) {
            pop_back();
        }
    }
    
    void push_back(T value) {
        if (head == 0) {
            head = new Node<T>;
            head->value = value;
            length = length + 1;
            return;
        }
        Node<T> *current = head;
        for (int i = 0; i < (length - 1); ++i) {
            current = current->next;
        }
        current->next = new Node<T>;
        current->next->value = value;
        length++;
        return;
    }
    
    void pop_back() {
        if (head == 0) {
            return;
        }
        if (length == 1) {
            delete head;
            head = 0;
            length = 0;
            return;
        }
        Node<T> *current = head;
        for (int i = 0; i < (length - 2); ++i) {
            current = current->next;
        }
        delete current->next;
        length--;
        return;
    }
    
    void print() {
        if (head == 0) {
            cout << "LIST IS EMPTY!" << endl;
            return;
        }
        Node<T> *current = head;
        for (int i = 0; i < (length - 1); ++i) {
            cout << current->value << " ";
            current = current->next;
        }
        cout << current->value << endl;
    }
    
    void elementSwap(int pos) {
        if ((pos < 0)|(pos >= (length - 1))) {
            cout << "Range exceeded!" << endl;
            return;
        }
        Node<T> *current = head;
        T temp;
        for (int i = 0; i < pos; ++i) {
            current = current->next;
        }
        temp = current->value;
        current->value = current->next->value;
        current->next->value = temp;
    }

};

template <typename T>
void listCopy( forward_list<T> L, forward_list<T>& P ) {
    T temp;
    forward_list<T> templist;
    while (!P.empty()) {
        temp = P.front();
        templist.push_front(temp);
        P.pop_front();
    }
    while (!L.empty()) {
        temp = L.front();
        P.push_front(temp);
        L.pop_front();
    }
    while (!templist.empty()) {
        temp = templist.front();
        P.push_front(temp);
        templist.pop_front();
    }
}

template <typename T>
void printLots (forward_list <T> L, forward_list <int> P) {
    int Num = 0;
    while (!L.empty()) {
        if (Num == P.front()) {
            cout << L.front() << " ";
            P.pop_front();
            if (P.empty()) {
                cout << endl;
                return; }
        }
        Num = Num + 1;
        L.pop_front();
    }
    cout << endl;
}

#endif