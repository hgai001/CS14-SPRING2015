#include <iostream>
#include <stack>
#include "lab3.h"

#define NUMBER 20
using namespace std;

template<typename T> 
void showTowerStates(int n, stack<T>& A, stack<T>& B, stack<T>& C) {
    if (n <= 0) {
        cout << "Elements in Stack \"A\" should be at least 1!" << endl;
    }
    else if (n == 1) {
        C.push(A.top());
        A.pop();
    }
    else {
        showTowerStates((n - 1), A, C, B);
        C.push(A.top());
        A.pop();
        showTowerStates((n - 1), B, A, C);
    }
}
template<typename T> 
void printStack(stack<T> A) {
    while(!A.empty()) {
        cout << A.top() << endl;
        A.pop();
    }
}
int main() {
    int i = 0;
    //TwoStackFixed test:
    cout <<"TwoStackFixed test:" << endl;
    TwoStackFixed<int> first(10,5);
    for (i = 0; !first.isFullStack1(); ++i) {
        first.pushStack1(i);
    }
    cout << "Stack 1:" << endl;
    while (!first.isEmptyStack1()) {
        cout << first.popStack1() << endl;
    }
    for (i = 0; !first.isFullStack2(); ++i) {
        first.pushStack2(i);
    }
    cout << "Stack 2:" << endl;
    while (!first.isEmptyStack2()) {
        cout << first.popStack2() << endl;
    }
    //TwoStackOptial test:
    cout <<"TwoStackOptial test:" << endl;
    TwoStackOptimal<int> second(10);
    for (i = 0; i < 5; ++i) {
        second.pushFlexStack1(i);
    }
    for (i = 0; i < 5; ++i) {
        second.pushFlexStack2(i);
    }
    cout << "Stack 1:" << endl;
    while (!second.isEmptyStack1()) {
        cout << second.popFlexStack1() << endl;
    }
    cout << "Stack 1:" << endl;
    while (!second.isEmptyStack2()) {
        cout << second.popFlexStack2() << endl;
    }
    cout << "Tower of Hanoi:" << endl;
    stack<int> A, B, C;
    for (i = 1; i < (NUMBER + 1); ++i) {
        A.push(i);
    }
    showTowerStates(NUMBER, A, B, C);
    printStack(C);
}
