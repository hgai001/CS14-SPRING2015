#ifndef BST_H
#define BST_H
#include <cassert>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <sstream>
#include <map>
#include <list>
#include <math.h>
#include <stack>
using namespace std;
#define nil 0
//#define Value int // restore for testing.
template < typename Value >
class BST {
    class Node { // binary tree node
        public:
        Node* left;
        Node* right;
        Value value;
        int selected;
        Node (const Value v){value = v; left = nil; right = nil;}
        Value& content() { return value; }
        bool isInternal() { return (left != nil) && (right != nil); }
        bool isExternal() { return (left != nil) || (right != nil); }
        bool isLeaf() { return (left == nil) && (right == nil); }
        int height() {
            // returns the height of the subtree rooted at this node
            // FILL IN
            if (isLeaf()) {
                return 0;
            }
            if (isInternal()) {
                if (left->height() > right->height()) {
                    return (1 + left->height());
                }
                else {
                    return (1 + right->height());
                }
            }
            else if (right == nil) {
                return (1 + left->height());
            }
            else {
                return (1 + right->height());
            }
        }
        int size() {
            // returns the size of the subtree rooted at this node,
            // FILL IN
            if (this == nil) {
                return 0;
            }
            else if (isLeaf()) {
                return 1;
            }
            else {
                return (1 + left->size() + right->size());
            }
        }
        void preorderPrint() {
            if (this == nil) {
                return;
            }
            cout << value <<" ";
            left->preorderPrint();
            right->preorderPrint();
        }
        void postorderPrint() {
            if (this == nil) {
                return;
            }
            left->postorderPrint();
            right->postorderPrint();
            cout << value <<" ";
        }
        void inorderPrint() {
            if (this == nil) {
                return;
            }
            left->inorderPrint();
            cout << value <<" ";
            right->inorderPrint();
        }
        bool nodesearch(Value x) {
            if (this == nil) {
                return false;
            }
            if (value == x) {
                return true;
            }
            return (left->nodesearch(x) || right->nodesearch(x));
        }
        Value& find(int n) {
            if (n > (size() - 1)) {
                cout << "Range Exceeded!" << endl;
                return value;
            }
            else if (left->size() == n) {
                return value;
            }
            else if (left->size() > n) {
                return left->find(n);
            }
            else {
                return right->find(n - left->size() - 1);
            }
        }
        int Coverselect() {
            if (this == nil) {
                return 1;
            }
            else if (isLeaf()) {
                selected = 0;
                return 0;
            }
            else {
                left->Coverselect();
                right->Coverselect();
                selected = !(left->Coverselect() && right->Coverselect());
                return selected;
            }
        }
        
    }; // Node
    // const Node* nil; // later nil will point to a sentinel node.
    int count;
    int vertex_cover_size;
    
    public:
    //Lab5 modified
        Node* root;
        map<int, int> m;
        void minCover() {
            root->Coverselect();
        }
        void Selectedprint(Node *node) {
            if (node == nil) {
                return;
            }
            Selectedprint(node->left);
            if (node->selected) {
                cout << node->value <<" ";
                vertex_cover_size++;
            }
            Selectedprint(node->right);
        }
        void displayMinCover() {
            vertex_cover_size = 0;
            Selectedprint(root);
            cout << endl;
            cout << vertex_cover_size << endl;
        }
        int hasSumPath(Node *n, int sum) {
            if(n == nil) {
                return 0;
            }
            n->selected = 0;
            if( (n->value == sum)&&(n->isLeaf()) ) {
                n->selected = 1;
                return 1;
            }
            if( (n->value == sum)&& (!(n->isLeaf())) ) {
                n->selected = 0;
                return 0;
            }
            if(n->value > sum) {
                return 0;
            }
            int tmp1 = hasSumPath(n->left, (sum - n->value));
            int tmp2 = hasSumPath(n->right, (sum - n->value));
            n->selected = tmp1 + tmp2; 
            return (tmp1 + tmp2);
        }
        void SumPathprint(Node *n) {
            if(n == nil) return;
            if(n->selected == 0) return;
            if (n->isLeaf()) {
                cout << n->value << " ";
                n->selected = n->selected - 1;
                return;
            }
            if (n->left == nil) {
                cout << n->value << " ";
                n->selected = n->selected - 1;
                SumPathprint(n->right);
            }
            else if(n->left->selected !=0) {
                SumPathprint(n->left);
                cout << n->value << " ";
                n->selected = n->selected - 1;
            }
            else {
                cout << n->value << " ";
                n->selected = n->selected - 1;
                SumPathprint(n->right);
            }
        }
        void findSumPath(Node *n, int sum, int buffer[]) {
            int num = hasSumPath(n, sum);
            if(num == 0) {
                cout << 0 << endl;
                return;
            }
            for (int i = 0; i < num; i++) {
                SumPathprint(n);
                cout << endl;
            }
            return;
        }
        void vertSum(Node* node, int hd, std::map<int, int>& m) {
            int max = 0;
            int min = 0;
            vertical_sum(node, hd, m, &max, &min);
            for(; min <= max; ++min) {
                cout << m[min] << " ";
            }
            cout << endl;
        }
        void vertical_sum(Node* node, int hd, std::map<int, int>& m, int *max, int *min) {
            if (node == nil) return;
            int index = hd;
            if(index > (*max)) *max = index;
            if(index < (*min)) *min = index;
            m[index] = m[index] + node->value;
            vertical_sum(node->left, hd-1, m, max, min);
            vertical_sum(node->right, hd+1, m, max, min);
        }
        int size() {
            // size of the overall tree.
            // FILL IN
            return root->size();
        }
        bool empty() { return size() == 0; }
        void print_node( const Node* n ) {
            // Print the node’s value.
            // FILL IN
            cout << n->value << endl;
        }
        bool search ( Value x ) {
            // search for a Value in the BST and return true iff it was found.
            // FILL IN
            return root->nodesearch(x);
        }
        void preorder()const {
            // Traverse and print the tree one Value per line in preorder.
            // FILL IN
            root->preorderPrint();
            cout << endl;
        }
        void postorder()const {
            // Traverse and print the tree one Value per line in postorder.
            // FILL IN
            root->postorderPrint();
            cout << endl;
        }
        void inorder()const {
            // Traverse and print the tree one Value per line in inorder.
            // FILL IN
            root->inorderPrint();
            cout << endl;
        }
        Value& operator[] (int n) {
            // returns reference to the value field of the n-th Node.
            // FILL IN
            return root->find(n);
            
        }
        BST() {count = 0; root = nil;}
        void insert( Value X ) { 
            root = insert( X, root ); 
        }
        Node* insert( Value X, Node* T) {
            // The normal binary-tree insertion procedure ...
            if ( T == nil ) {
                T = new Node( X ); // the only place that T gets updated.
            } else if ( X < T->value ) {
                T->left = insert( X, T->left );
            } else if ( X > T->value ) {
                T->right = insert( X, T->right );
            } else {
                T->value = X;
            }
            // later, rebalancing code will be installed here
            return T;
        }
        void remove( Value X ) { root = remove( X, root ); }
        Node* remove( Value X, Node*& T ) {
            // The normal binary-tree removal procedure ...
            // Weiss’s code is faster but way more intricate.
            if ( T != nil ) {
                if ( X > T->value ) {
                    T->right = remove( X, T->right );
                } else if ( X < T->value ) {
                    T->left = remove( X, T->left );
                } else {
                    // X == T->value
                    if ( T->right != nil ) {
                        Node* x = T->right;
                        while ( x->left != nil ) x = x->left;
                        T->value = x->value; // successor’s value
                        T->right = remove( T->value, T->right );
                    } else if ( T->left != nil ) {
                        Node* x = T->left;
                        while ( x->right != nil ) x = x->right;
                        T->value = x->value; // predecessor’s value
                        T->left = remove( T->value, T->left );
                    } else { // *T is external
                        delete T;
                        T = nil; // the only updating of T
                    }
                }
            }
            // later, rebalancing code will be installed here
            return T;
        }
        void okay( ) { okay( root ); }
        void okay( Node* T ) {
            // diagnostic code can be installed here
            return;
        }
}; // BST
#endif