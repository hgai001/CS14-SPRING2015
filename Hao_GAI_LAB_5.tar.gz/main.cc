//Name: Hao Gai
//SID: 606362 (GPP-E)
//May 11th, 2015

#include "lab5.h"
#include <iostream>
using namespace std;

int main() {
    BST<int> bst;
    // Test case 1:
    int arr1[] = {50, 20, 60, 10, 15, 25, 70, 55};
    for(int i = 0; i < 8; ++i) {
        bst.insert(arr1[i]);
    }
    cout << "Original tree (inorder): ";
    bst.inorder();
    bst.minCover();
    cout << "Part1:" << endl;
    bst.displayMinCover();
    cout << "Part2:" << endl;
    int buffer[100];
    bst.findSumPath(bst.root, 95, buffer);
    cout << "Part3:" << endl;
    bst.vertSum(bst.root, 0, bst.m);
}