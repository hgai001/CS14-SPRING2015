#include <iostream>
#include <fstream>
#include <set>
#include <unordered_set>
#include <string>
#include <vector>
#include <ctime>

using namespace std;
int main() {
    vector<string> words;
    ifstream infile("words.txt", ios::in);
    string temp;
    while(getline(infile,temp)) {
       words.push_back(temp);
    }
    ofstream datafile;
    datafile.open("data.txt", ios::trunc);
    clock_t t1, t2, t3, t4;
    set<string> tree;
    unordered_set<string> hash;
    for (int N = 5000; N <= 50000; N+=5000) {
        cout << "n=" << N;
        datafile << N;
        t1 = clock();
        for(int i = 0; i < N; ++i) {
            tree.insert(words[i]);
        }
        t1 = clock() - t1;
        t2 = clock();
        for(int i = 0; i < N; ++i) {
            hash.insert(words[i]);
        }
        t2 = clock() - t2;
        t3 = clock();
        for(int i = 0; i < N; ++i) {
            tree.find(words[i]);
        }
        t3 = clock() - t3;
        t4 = clock();
        for(int i = 0; i < N; ++i) {
            hash.find(words[i]);
        }
        t4 = clock() - t3;
        cout << " tree-insert-time " << ((float)t1)/CLOCKS_PER_SEC << "s";
        cout << " hash-insert-time " << ((float)t2)/CLOCKS_PER_SEC << "s";
        cout << " tree-query-time " << (((float)t3)/CLOCKS_PER_SEC)/N << "s";
        cout << " hash-query-time " << (((float)t4)/CLOCKS_PER_SEC)/N << "s";
        cout << endl;
        datafile << " " << 1000*((float)t1)/CLOCKS_PER_SEC;
        datafile << " " << 1000*((float)t2)/CLOCKS_PER_SEC;
        datafile << " " << 1000*(((float)t3)/CLOCKS_PER_SEC)/N;
        datafile << " " << 1000*(((float)t4)/CLOCKS_PER_SEC)/N;
        datafile << endl;
    }
    datafile.close();
}


/*
        // t3 is the time to find all those elements in a tree
        int x = 0;
        t3 = clock();
        while(x < n)
        {   
            it_tree = tree.find(words[x]);
            ++x;
        }
        t3 = clock() - t3;
        
        // t4 is the time to find all those elemtns in a hash table
        x = 0;
        t4 = clock();
        while(x < n)
        {
            it_hash = hash.find(words[x]);
            ++x;
        }
        t4 = clock() - t4;






5000 4.804 1.866 0.0006114 0.0001894
10000 8.895 2.856 0.0006271 0.0002024
15000 12.505 4.109 0.000666467 0.000264133
20000 18.013 6.513 0.0006869 0.0002454
25000 23.595 7.774 0.00074792 0.00031284
30000 25.336 8.419 0.0007036 0.000301833
35000 31.493 14.363 0.000753971 0.000299629
40000 33.877 15.167 0.00074175 0.000355725
45000 41.258 16.41 0.000718444 0.000315089
50000 45.515 15.844 0.0007639 0.00032584



*/