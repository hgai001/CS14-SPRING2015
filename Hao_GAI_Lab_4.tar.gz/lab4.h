#ifndef lab4_h
#define lab4_h

#include <iostream>
#include<vector>
#include<algorithm>

using namespace std;
typedef pair<int,int> Entry;
class priority_queue {
public:
  vector<Entry> entries;
  Entry& front() { return entries.back(); }
  void pop() { entries.pop_back(); }
  void push( Entry e ) {
    entries.push_back( e );
    for ( int i = entries.size()-1; i != 0; --i ) {
      if ( (entries[i].first + entries[i].second) < (entries[i-1].first + entries[i-1].second) ) break;
      swap(entries[i], entries[i-1]);
    }
  }
};

void pre_Coprimes(int m, int n, int k) {
    if ((m + n) > k) {
        return;
    }
    cout << m << " " << n << endl;
    pre_Coprimes((2*m - n), m, k);
    pre_Coprimes((2*m + n), m, k);
    pre_Coprimes((m + 2*n), n, k);
    return;
}

void preOrder(int k) {
    cout << "Pre-order:" << endl;
    pre_Coprimes(2, 1, k);
    pre_Coprimes(3, 1, k);
}

void post_Coprimes(int m, int n, int k) {
    if ((m + n) > k) {
        return;
    }
    post_Coprimes((2*m - n), m, k);
    post_Coprimes((2*m + n), m, k);
    post_Coprimes((m + 2*n), n, k);
    cout << m << " " << n << endl;
}

void postOrder(int k) {
    cout << "Post-order:" << endl;
    post_Coprimes(2, 1, k);
    post_Coprimes(3, 1, k);
}

void sort_Coprimes(int m, int n, int k, priority_queue &coprimes) {
    if ((m + n) > k) {
        return;
    }
    Entry tmp(m, n);
    coprimes.push(tmp);
    sort_Coprimes((2*m - n), m, k, coprimes);
    sort_Coprimes((2*m + n), m, k, coprimes);
    sort_Coprimes((m + 2*n), n, k, coprimes);
}

void sortOrder(int k) {
    priority_queue coprimes;
    sort_Coprimes(2, 1, k, coprimes);
    sort_Coprimes(3, 1, k, coprimes);
    Entry tmp;
    cout << "Sorted:" << endl;
    while (!coprimes.entries.empty()) {
        tmp = coprimes.front();
        cout << tmp.first << " " << tmp.second << endl;
        coprimes.pop();
    }
}

#endif