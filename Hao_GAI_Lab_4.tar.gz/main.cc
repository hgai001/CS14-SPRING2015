//Name: Hao Gai
//SID: 606362 GPP-E program
//May.2nd, 2015

#include <iostream>
#include "lab4.h"

using namespace std;

int main( int argc, char* argv[] ) {
    if ( argc != 2 ) {
        cout << "Usage: ./<executable_file> <Max_coprimes_sum> \n";
        exit(-1);
    }
    int sum = strtol(argv[1], 0, 10 );
    preOrder( sum );
    postOrder( sum );
    sortOrder( sum );
}
