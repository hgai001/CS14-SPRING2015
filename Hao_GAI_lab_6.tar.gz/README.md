My selectionsort is a stable function.
a.  The reason for that is when the two values are equal, they will not swap. 
    Only when the current value is samller than minimum will they swap.
b.  To test if the function is stable, we can use the function to sort a list of same numbers.
    If the number of moves is 0, then it is stable.