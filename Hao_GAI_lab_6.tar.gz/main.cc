//Name: Hao GAI
//SID: 606362 (GPP-E)
//May 16th, 2015

#include <iostream>
#include <algorithm>
#include <list>
#include <vector>
#include <utility>

using namespace std;

template<typename L>
void selectionsort(L &l) {
    int moves = 0;
    typename L::iterator min;
    for(auto i = l.begin(); i != l.end(); ++i) {
        min = i;
        for(auto j = i; j != l.end(); ++j) {
            if(*j < *min) min = j;
        }
        if (i != min) {
            swap (*i, *min);
            moves += 3;
        }
    }
    cout << "Sorting completed, 0 copies and " << moves << " moves" << endl;
}

int main() {
    vector<int> l1;
    int arr[] = {2, 4, 5, 1, 8, 9};
    for (int i  = 0; i < 6; ++i) {
        l1.push_back(arr[i]);
    }
    cout << "pre:  ";
    for(auto i = l1.begin(); i != l1.end(); ++i) {
        cout << *i << " ";
    }
    cout << endl;
    selectionsort(l1);
    cout << "post: ";
    for(auto i = l1.begin(); i != l1.end(); ++i) {
        cout << *i << " ";
    }
    cout << endl << endl;
    //test2
    typedef pair<int, int> points;
    list<points> l2;
    l2.push_back(make_pair(1, 2));
    l2.push_back(make_pair(3, -1));
    l2.push_back(make_pair(-1, 3));
    l2.push_back(make_pair(0, 0));
    l2.push_back(make_pair(2, 3));
    l2.push_back(make_pair(1, 2));
    l2.push_back(make_pair(1, -2));
    l2.push_back(make_pair(8, 10));
    cout << "pre:  ";
    for(auto i = l2.begin(); i != l2.end(); ++i) {
        cout << "(" << i->first << ", " << i->second << ") ";
    }
    cout << endl;
    selectionsort(l2);
    cout << "post: ";
    for(auto i = l2.begin(); i != l2.end(); ++i) {
        cout << "(" << i->first << ", " << i->second << ") ";
    }
    cout << endl << endl;
    
    cout << "pre:  ";
    for(auto i = l2.begin(); i != l2.end(); ++i) {
        cout << "(" << i->first << ", " << i->second << ") ";
    }
    cout << endl;
    selectionsort(l2);
    cout << "post: ";
    for(auto i = l2.begin(); i != l2.end(); ++i) {
        cout << "(" << i->first << ", " << i->second << ") ";
    }
    cout << endl << endl;
    
    list<points> l3;
    l3.push_back(make_pair(10, 2));
    l3.push_back(make_pair(-3, -1));
    l3.push_back(make_pair(-8, 0));
    l3.push_back(make_pair(1, 1));
    l3.push_back(make_pair(1, 1));
    l3.push_back(make_pair(0, 0));
    l3.push_back(make_pair(10, 2));
    l3.push_back(make_pair(5, 5));
    l3.push_back(make_pair(5, -5));
    l3.push_back(make_pair(0, 0));
    l3.push_back(make_pair(10, 2));
    cout << "pre:  ";
    for(auto i = l3.begin(); i != l3.end(); ++i) {
        cout << "(" << i->first << ", " << i->second << ") ";
    }
    cout << endl;
    selectionsort(l3);
    cout << "post: ";
    for(auto i = l3.begin(); i != l3.end(); ++i) {
        cout << "(" << i->first << ", " << i->second << ") ";
    }
    cout << endl << endl;
}